import styled from 'styled-components';

export const RightPanelBtn = styled.button`
    width: 100%;
    height: 2.8rem;
    background-color: pink;
    border: none;
    border-radius: 25px;
`;

